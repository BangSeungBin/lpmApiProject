package test.junit.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJunitTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJunitTestApplication.class, args);
	}

}
