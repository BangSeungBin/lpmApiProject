package example.webflux.spring.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class ExampleService {

	public String getSampleExmaple1() {
		
		return "Example1";
			
	}

	public String getSampleExmaple2() {

		return "Example2";
			
	}

	public String getSampleExmaple3() {

		return "Example3";
			
	}
	
	public String getSampleExmaple4() {

		return "Example4";
			
	}
}
