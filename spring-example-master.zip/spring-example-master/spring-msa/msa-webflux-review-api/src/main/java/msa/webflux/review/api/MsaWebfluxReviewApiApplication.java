package msa.webflux.review.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsaWebfluxReviewApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsaWebfluxReviewApiApplication.class, args);
	}

}
