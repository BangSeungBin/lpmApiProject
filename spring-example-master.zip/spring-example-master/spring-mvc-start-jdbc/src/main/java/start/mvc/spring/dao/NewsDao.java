package start.mvc.spring.dao;

import java.util.List;

import start.mvc.spring.vo.News;

public interface NewsDao {
	
	public List<News> getNews();
	
}
