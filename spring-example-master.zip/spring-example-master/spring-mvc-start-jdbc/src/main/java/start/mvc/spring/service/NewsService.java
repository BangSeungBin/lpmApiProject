package start.mvc.spring.service;

import java.util.List;

import start.mvc.spring.vo.News;

public interface NewsService {
	
	public List<News> getNews();
	
}
